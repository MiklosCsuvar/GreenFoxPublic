public class Main {
    public static void main(String[] args) {
        long start = System.nanoTime();
        long number = 0;
        long divisor = 0;
        long limit = 0;
        long primelimit = 0;
        boolean isprime = false;

        limit = 100000000;
        System.out.println("These are the prime numbers not greater than " + limit +":");
        for(number=2; number<=limit; number++)
        {
            isprime = true;
            primelimit = (long)(Math.sqrt((double)number));
            for(divisor=2; divisor<=primelimit; divisor++)
            {
                if(number%divisor == 0)
                {
                    isprime = false;
                    break;
                }
            }

            if(isprime)
            {
                System.out.print(number +" ");
            }
        }
        System.out.print("\n");

        long end = System.nanoTime();
        System.out.println("Running time (s): " + (double)(end - start)/(double)1000000000);
    }
}