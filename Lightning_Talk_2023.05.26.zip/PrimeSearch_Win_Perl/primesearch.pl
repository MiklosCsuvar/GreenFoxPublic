#! Perl

use Time::HiRes qw( time );

my $start = time();

$e = 100000000;
print "These are the prime numbers not greater than: $e";
print "\n";

for($i=2; $i<=$e; $i++){
    $p = 1;
    $limit=sqrt($i);
    for($j=2; $j<=$limit; $j++){
        if($i % $j==0){
            $p = 0;
            last;
        }
    }
    if ($p == 1){
        print "$i ";
    }
}

sleep(1.2);

my $end = time();
print "\n";
printf("Execution Time: %0.02f s\n", $end - $start);