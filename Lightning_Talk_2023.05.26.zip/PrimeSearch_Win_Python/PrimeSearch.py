import math
import time

start_time = time.time()
number = 0
divisor = 0
limit = 0
primelimit = 0
isprime = False

limit = 100000 + 1
print("These are the prime numbers not greater than", limit-1, ":")
for number in range (2, limit, 1):
    isprime = True
    primelimit = math.floor(math.sqrt(number)) + 1
    for divisor in range(2, primelimit, 1):
        if number%divisor == 0:
            isprime = False
            break
    if isprime:
        print(number, end =" ")
print()
print("Running time (s): ", (time.time() - start_time))
