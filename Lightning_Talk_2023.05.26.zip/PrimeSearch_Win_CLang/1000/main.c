#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    long long number = 0;
    long long divisor = 0;
    long long limit = 0;
    long long primelimit = 0;
    char isprime = 0;

    limit = 1000;
    printf("These are the prime numbers not greater than %I64d:\n", limit);
    for(number=2; number<=limit; number++)
    {
        isprime = 1;
        primelimit = (long long)(sqrt((double)number));
        for(divisor=2; divisor<=primelimit; divisor++)
        {
            if(number%divisor == 0)
            {
                isprime = 0;
                break;
            }
        }

        if(isprime)
        {
            printf("%I64d ", number);
        }
    }

    return 0;
}
